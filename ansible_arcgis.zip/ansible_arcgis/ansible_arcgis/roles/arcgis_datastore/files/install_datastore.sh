#!/usr/bin/env bash

sudo -u arcgis /data/software/ArcGISDataStore_Linux/Setup -m silent -l yes -d /data/esri