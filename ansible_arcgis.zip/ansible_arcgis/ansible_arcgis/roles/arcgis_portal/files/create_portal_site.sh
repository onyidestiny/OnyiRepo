#!/usr/bin/env bash

sudo -u arcgis /opt/esri/arcgis/portal/tools/createportal -fn portal -ln admin -u <portaladmin user> -p <your password> -e <email address> -qi 1 -q <your answer> -d /opt/esri/arcgis/portal/usr/arcgisportal