#!/usr/bin/env bash

sudo -u arcgis /data/software/PortalForArcGIS/Setup -m silent -l yes -d /data/esri -a <path to license file>