#!/usr/bin/env bash

sudo -u arcgis /data/software/PortalForArcGIS/Setup -m silent -l yes -d /data/esri -a /data/software/YourServerLicense105.prvc