#!/usr/bin/env bash

sudo -u arcgis /data/software/ArcGISServer/Setup -m silent -l yes -d /data/esri -a /data/software/YourServerLicense104.prvc